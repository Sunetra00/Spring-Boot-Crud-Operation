package com.fileUpload.Poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadPoc1Application {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadPoc1Application.class, args);
	}

}
